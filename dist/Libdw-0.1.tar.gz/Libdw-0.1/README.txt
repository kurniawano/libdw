=====
LIBDW
=====

Libdw is a library used in 10.009 Digital World conducted at SUTD freshmore. Typical usage often looks like this::

    #!/usr/bin/env python

    from libdw import kinematics as kn
    from libdw import sm
    
INSTALLATION
============


